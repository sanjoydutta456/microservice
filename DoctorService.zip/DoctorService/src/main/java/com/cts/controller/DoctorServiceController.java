package com.cts.controller;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cts.dto.Doctor;

@RestController



public class DoctorServiceController {
	
    @Autowired
	DiscoveryClient discoveryClient;
	
	@GetMapping("/getDoctorList")
	List<Doctor> getDoctorList()
	{
		System.out.println("1111");
		List<ServiceInstance> instances=discoveryClient.getInstances("diagnosis-service");
		ServiceInstance serviceInstance=instances.get(0);
		String baseUrl=serviceInstance.getUri().toString();
        ResponseEntity<String[]> response = new RestTemplate().getForEntity(baseUrl +"/getDiagnosis", String[].class);
        System.out.println("5555:"+response);
  		List<String> dList= Arrays.asList(response.getBody());
		List<Doctor> docList=new ArrayList<Doctor>();
		Doctor d1=new Doctor("D001","Suman Bose");
		Doctor d2=new Doctor("D002","Amit Roy");
		docList.add(d1);
		docList.add(d2);
		return docList;
	}
	
	 public String getBaseURL(DiscoveryClient discoveryClient,String instanceName)
	    {
	    	List<ServiceInstance> instances=discoveryClient.getInstances(instanceName);
			ServiceInstance serviceInstance=instances.get(0);
			String baseUrl=serviceInstance.getUri().toString();
			return baseUrl;
	    }
	
	
@GetMapping("/getDepartmentList")	
List<String> getDepartmentList()
{
	List<String> deptList=new ArrayList<String>();
	String s1="Medicine";
	String s2="Cardiology";
	deptList.add(s1);
	deptList.add(s2);
	return deptList;
}

}
