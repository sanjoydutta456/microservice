package com.cts;

import java.util.Scanner;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;



public class TutorialRestClient {
	
	static RestTemplate restTemplate = new RestTemplate();
	static String baseUrl = "http://localhost:22221";

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		char isValid='N';
		do
		{
		System.out.println("1.Insert Data");
		System.out.println("2.Retrieve Data");
		System.out.println("Enter your choice:");
		int ch=Integer.parseInt(sc.nextLine());
		switch(ch)
		{
		case 1:
			System.out.println("Enter the title:");
			String title=sc.nextLine();
			System.out.println("Enter the description:");
			String desc=sc.nextLine();
			System.out.println("Enter the published:");
			boolean isPublished=Boolean.parseBoolean(sc.nextLine());
			Tutorial tt=new Tutorial();
			tt.setTitle(title);
			tt.setDescription(desc);
			tt.setPublished(isPublished);
			saveTutorial(tt);
			break;
		case 2:
			retrieve();
			break;
		default:
			System.out.println("Wrong Choice");
			  
		}
		
		System.out.println("Want to do more operations(Y/N):");
		isValid=sc.nextLine().charAt(0);
		}while(isValid=='Y');
		
		sc.close();
		
	
		
	}



	private static void retrieve() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Tutorial> requestEntity = new HttpEntity<>(headers);
	    ResponseEntity<Tutorial[]> responseEntity = restTemplate.exchange(baseUrl + "/api/tutorialsRest", HttpMethod.GET,
				requestEntity,Tutorial[].class);
		HttpStatus statusCode = responseEntity.getStatusCode();
		if(statusCode==HttpStatus.OK)
		{
		Tutorial[] tutorialList=responseEntity.getBody();
		System.out.println(tutorialList);
		
		for(Tutorial tutorial:tutorialList)
		{
			System.out.println(tutorial);
		}
		}
	}
	
	
	
	public static void saveTutorial(Tutorial tuorial) {

		HttpHeaders headers = new HttpHeaders();
		headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
		headers.setContentType(MediaType.APPLICATION_JSON);

		RestTemplate restTemplate = new RestTemplate();

		// Data attached to the request.
		HttpEntity<Tutorial> requestBody = new HttpEntity<>(tuorial, headers);

		// Send request with POST method.
		restTemplate.postForObject(baseUrl+"/api/tutorials", requestBody, Tutorial.class);

	}

}
