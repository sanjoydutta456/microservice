package com.cts.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.cts.model.Purchase;
import com.cts.model.Sales;
@Service
public class DashboardService {
	
	static RestTemplate restTemplate = new RestTemplate();
	//static String salesBaseUrl = "http://localhost:8787/api";
	//static String purchaseBaseUrl = "http://localhost:9797/api";
	
    public String getBaseURL(DiscoveryClient discoveryClient,String instanceName)
    {
    	List<ServiceInstance> instances=discoveryClient.getInstances(instanceName);
		ServiceInstance serviceInstance=instances.get(0);
		String baseUrl=serviceInstance.getUri().toString();
		return baseUrl;
    }
	
	public Sales[] retrieveSalesData(DiscoveryClient discoveryClient )
	{
		
		
		String salesBaseUrl=getBaseURL(discoveryClient,"sales-service");
		System.out.println("SalesBaseURL:"+salesBaseUrl);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Sales> requestEntity = new HttpEntity<>(headers);
		ResponseEntity<Sales[]> responseEntity = restTemplate.exchange(salesBaseUrl + "/api/getAllSalesData", HttpMethod.GET,
				requestEntity,Sales[].class);
		HttpStatus statusCode = responseEntity.getStatusCode();
		System.out.println(statusCode);
		Sales[] salesList=responseEntity.getBody();
		return salesList;
	}
	
	public Purchase[] retrievePurchaseData(DiscoveryClient discoveryClient)
	{
		String purchaseBaseUrl=getBaseURL(discoveryClient,"purchase-service");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Purchase> requestEntity = new HttpEntity<>(headers);
		ResponseEntity<Purchase[]> responseEntity = restTemplate.exchange(purchaseBaseUrl + "/api/getAllPurchaseData", HttpMethod.GET,
				requestEntity,Purchase[].class);
		HttpStatus statusCode = responseEntity.getStatusCode();
		System.out.println(statusCode);
		Purchase[] purchaseList=responseEntity.getBody();
		return purchaseList;
	}
		
	
/*	public void createSales()
	{
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		Sales sales = new Sales();
		HttpEntity<Sales> requestEntity = new HttpEntity<>(sales, headers);
		//restTemplate.postForObject(url, requestBody, Sales.class);
		//restTemplate.exchange(salesBaseUrl+"/SalesPage", HttpMethod.GET,requestEntity,Sales.class);
	} */

	/*public void purchaseDelete(Long id)
	
	{
		String url=purchaseBaseUrl+"/purchaseDelete/{id}";
		System.out.println(url);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.TEXT_HTML);
		Purchase purchase = new Purchase();
		HttpEntity<Purchase> requestBody = new HttpEntity<>(purchase, headers);
		restTemplate.postForObject(url, requestBody, Purchase.class);
	}*/
	
	}

