package com.cts.model;

public class Purchase {
	
	private Long id;
	private String purchaseItem;
	private String purchasePrice;
	
	public Long getId() {
			return id;
		}


		public void setId(Long id) {
			this.id = id;
		}


	public Purchase(Long id,String purchaseItem, String purchasePrice) {
		super();
		this.id=id;
		this.purchaseItem = purchaseItem;
		this.purchasePrice = purchasePrice;
	}


	public Purchase() {
		super();
		// TODO Auto-generated constructor stub
	}


	public String getPurchaseItem() {
		return purchaseItem;
	}
	public void setPurchaseItem(String purchaseItem) {
		this.purchaseItem = purchaseItem;
	}
	public String getPurchasePrice() {
		return purchasePrice;
	}
	public void setPurchasePrice(String purchasePrice) {
		this.purchasePrice = purchasePrice;
	}


	@Override
	public String toString() {
		return "Purchase [id=" + id + ", purchaseItem=" + purchaseItem + ", purchasePrice=" + purchasePrice + "]";
	}


}
