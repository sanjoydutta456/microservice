package com.cts.model;


public class Sales {
	
	private Long id;
	private String salesItem;
	private String salesPrice;
	
	public Sales(String salesItem, String salesPrice) {
		super();
		this.salesItem = salesItem;
		this.salesPrice = salesPrice;
	}
	
	public Sales() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSalesItem() {
		return salesItem;
	}
	public void setSalesItem(String salesItem) {
		this.salesItem = salesItem;
	}
	public String getSalesPrice() {
		return salesPrice;
	}
	public void setSalesPrice(String salesPrice) {
		this.salesPrice = salesPrice;
	}
	@Override
	public String toString() {
		return "Sales [id=" + id + ", salesItem=" + salesItem + ", salesPrice=" + salesPrice + "]";
	}


}
