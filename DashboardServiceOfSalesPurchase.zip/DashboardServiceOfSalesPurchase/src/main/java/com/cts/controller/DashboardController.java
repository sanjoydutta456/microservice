package com.cts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.model.Purchase;
import com.cts.model.Sales;
import com.cts.service.DashboardService;


@Controller

public class DashboardController {
	
	@Autowired
	DashboardService dservice;
	
	@Autowired
	
	DiscoveryClient discoveryClient;
	
	
	@RequestMapping(value="/dashboard", method = RequestMethod.GET)
	
	public ModelAndView getDetails()
	{
		ModelAndView mv=new ModelAndView();
		
		Sales[] sales1= dservice.retrieveSalesData(discoveryClient);
		Purchase[] purchase= dservice.retrievePurchaseData(discoveryClient);
		mv.addObject("SalesDetails",sales1);
		mv.addObject("PurchaseDetails",purchase);
		mv.setViewName("Dashboard");
		return mv;
		
		
		
	}
	@RequestMapping(value="/createSales", method = RequestMethod.GET)
	public void createSales()
	{
		System.out.println("create sales ");
		dservice.createSales();
	}
	
	@RequestMapping(value="/purchaseDelete/{id}", method=RequestMethod.GET)
	public void purchaseDelete(@RequestParam(value="id") String id)
   {
		System.out.println("create delete ");
	    //dservice.purchaseDelete(Long.parseLong(id));	
   }
}
