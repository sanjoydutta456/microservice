package com.cts.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cts.model.Sales;
import com.cts.service.SalesService;

@RestController
@RequestMapping("/api")

public class SalesController {

	@Autowired
	SalesService salesService;
	

	@GetMapping(value="/SalesPage")
	public ModelAndView show()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("SalesPage");
		return mv;
	}

	@PostMapping("/saveSalesData")
	public ModelAndView saveSalesData(@RequestParam String salesItem, @RequestParam String salesPrice)
	{
		ModelAndView mv = new ModelAndView();

		Sales salesObj=new Sales();
		salesObj.setSalesItem(salesItem);
		salesObj.setSalesPrice(salesPrice);
		salesService.save(salesObj);
		mv.setViewName("SalesSuccessPage");
		return mv;
		
	}
	
	@GetMapping("/getAllSalesData")
	public ModelAndView getAllData()
	{
    ModelAndView mv=new ModelAndView();
	List<Sales> salesList=new ArrayList<>();
	salesList=salesService.getAllData();
	mv.addObject("SalesDetails",salesList);
	mv.setViewName("SalesDetails");
	return mv;
}
	
	@GetMapping("/salesDelete/{id}")
	public ModelAndView purchaseDelete(@PathVariable("id") String id )
 	{
	  
	   salesService.salesDelete(Long.parseLong(id));
	   ModelAndView mv=new ModelAndView();
	   mv.setViewName("salesDelete");
	   return mv;
	   	   
 	}

	@GetMapping("/salesUpdate/{id}")
	
	public ModelAndView salesUpdate(@PathVariable("id") String id)
	
	{
		Optional<Sales> sal=salesService.findById(Long.parseLong(id));
		ArrayList<Sales> salList=new ArrayList<Sales>();
		Sales tempSale=new Sales();
		if (sal.isPresent()) {
			Sales sale = sal.get();
			tempSale.setId(sale.getId());
			tempSale.setSalesItem(sale.getSalesItem());
			tempSale.setSalesPrice(sale.getSalesPrice());
		}
		salList.add(tempSale);
		Map<String, Object> model = new HashMap<String, Object>();
		
		
		   model.put("salesUpdateData", salList);
		   return new ModelAndView("SalesUpdate",model);
	}
	
	@RequestMapping(method=RequestMethod.POST ,value="/salesUpdate/salesUpdateSave")
	public ModelAndView salesUpdateSave(@RequestParam String id,@RequestParam String salesItem, @RequestParam String salesPrice)
	{
		System.out.println("Calling salesUpdateSave method");
		ModelAndView mv = new ModelAndView();
		Sales salesObj=new Sales();
		salesObj.setId(Long.parseLong(id));
		salesObj.setSalesItem(salesItem);
		salesObj.setSalesPrice(salesPrice);
		salesService.save(salesObj);
		mv.setViewName("SalesSuccessPage");
		return mv;
		}
	
		
	
	
}