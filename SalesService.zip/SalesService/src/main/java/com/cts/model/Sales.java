package com.cts.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Sales {
	
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private Long id;

private String salesItem;
public Sales(String salesItem, String salesPrice) {
	super();
	this.salesItem = salesItem;
	this.salesPrice = salesPrice;
}
private String salesPrice;


public Sales() {
	super();
	// TODO Auto-generated constructor stub
}


public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public String getSalesItem() {
	return salesItem;
}
public void setSalesItem(String salesItem) {
	this.salesItem = salesItem;
}
public String getSalesPrice() {
	return salesPrice;
}
public void setSalesPrice(String salesPrice) {
	this.salesPrice = salesPrice;
}

}
