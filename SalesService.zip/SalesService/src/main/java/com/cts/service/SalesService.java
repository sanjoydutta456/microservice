package com.cts.service;

import java.util.List;
import java.util.Optional;

import com.cts.model.Sales;

public interface SalesService {
	
	Sales save(Sales sales);
	List<Sales> getAllData();
	public void salesDelete(Long id);
	public Optional<Sales> findById(Long id);
}
