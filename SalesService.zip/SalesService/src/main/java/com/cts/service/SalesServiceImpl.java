package com.cts.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Sales;
import com.cts.repository.SalesRepository;

@Service
public class SalesServiceImpl implements SalesService{
        
	@Autowired
	SalesRepository salesRepo;
	
	public Sales save(Sales sales) {
		
		return salesRepo.save(sales);
	}

	
	public List<Sales> getAllData() {
		
		List<Sales> salesList=new ArrayList<>();
		salesRepo.findAll().forEach(salesList::add);
		return salesList;
	}

	public void salesDelete(Long id)
	{
		salesRepo.deleteById(id);
	}
	
	public Optional<Sales> findById(Long id)
	{
		
	      return salesRepo.findById(id);
		
	}
	

}
