package com.cts.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.cts.model.Student;

@FeignClient(name="student-details-service")
public interface StudentDashboardService {

	@GetMapping(value="/student/allStudentDetails")
	public List<Student> getStudentDetails();
}
