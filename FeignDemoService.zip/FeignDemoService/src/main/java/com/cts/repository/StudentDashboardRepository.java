package com.cts.repository;

public class StudentDashboardRepository {

}
