package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.Student;
import com.cts.service.StudentDashboardService;

@RestController
@RequestMapping(value="/studentDashboard")
public class StudentDashboardController {

	    @Autowired
	    StudentDashboardService studentDashboardService;

	    @GetMapping(value = "/allStudents")
	    public List<Student> getAllStudents() {
	        return studentDashboardService.getStudentDetails();
	    }
	    
}
