package com.cts.controller;
	import java.util.ArrayList;
	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;

import com.cts.model.Library;
import com.cts.service.LibraryService;


	@RestController
	@RequestMapping("/api")
	public class LibraryController {
		
		@Autowired
		LibraryService libService;
		
		@PostMapping("/saveLibraryDetails")
		public ResponseEntity<Library> createEmployeeDetails(@RequestBody Library lib)
		{
			libService.saveLibraryDetails(new Library(lib.getBookName(),lib.getAuthor()));
			return new ResponseEntity<>(lib,HttpStatus.CREATED);
		}
		
		@GetMapping("/getAllLibraryDetails")
		public ResponseEntity<List<Library>> getAllLibraryDetails()
		{
			List<Library> libList=new ArrayList<Library>();
			libService.getAllLibraryDetails().forEach(libList::add);
			if (libList.isEmpty())
			{
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			else 
				return new ResponseEntity<>(libList,HttpStatus.OK);
		}
		

	}


