package com.cts.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Library {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public Long id;
	public String bookName;
	public String author;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public Library() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Library(String bookName, String author) {
		super();
		
		this.bookName = bookName;
		this.author = author;
	}
	@Override
	public String toString() {
		return "Library [id=" + id + ", bookName=" + bookName + ", author=" + author + "]";
	}
	

}
