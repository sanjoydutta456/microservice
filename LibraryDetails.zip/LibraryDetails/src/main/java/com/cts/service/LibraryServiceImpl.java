package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Library;
import com.cts.repository.LibraryRepository;
@Service
public class LibraryServiceImpl implements LibraryService {

	@Autowired
	LibraryRepository libRepo;
	
	public Library saveLibraryDetails(Library lib) {
		
		return libRepo.save(lib);
	}


	public List<Library> getAllLibraryDetails() {
		
		return libRepo.findAll();
	}

}
