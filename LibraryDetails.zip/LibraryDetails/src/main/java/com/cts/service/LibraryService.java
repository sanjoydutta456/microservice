package com.cts.service;

import java.util.List;

import com.cts.model.Library;

public interface LibraryService {
	
	Library saveLibraryDetails(Library lib);
	public List<Library> getAllLibraryDetails();

}
