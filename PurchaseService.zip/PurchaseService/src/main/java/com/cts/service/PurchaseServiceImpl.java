package com.cts.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Purchase;
import com.cts.repository.PurchaseRepository;
@Service
public class PurchaseServiceImpl implements PurchaseService {

	@Autowired
	PurchaseRepository purchaseRepo;
	
	public Purchase save(Purchase purchase) {
		return purchaseRepo.save(purchase);
	}


	public List<Purchase> getAllData() {
		List<Purchase> purchaseList = new ArrayList<>();
		purchaseRepo.findAll().forEach(purchaseList::add);
		return purchaseList;
		
	}
	
	public void purchaseDelete(Long id)
	{
		purchaseRepo.deleteById(id);
	}
	
	public Optional<Purchase> findById(Long id)
	{
		
	      return purchaseRepo.findById(id);
		
	}
	
}
