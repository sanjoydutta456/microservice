package com.cts.service;

import java.util.List;
import java.util.Optional;

import com.cts.model.Purchase;


public interface PurchaseService {
	
	Purchase save(Purchase purchase);
	List<Purchase> getAllData();
	public void purchaseDelete(Long id);
	public Optional<Purchase> findById(Long id);

}
