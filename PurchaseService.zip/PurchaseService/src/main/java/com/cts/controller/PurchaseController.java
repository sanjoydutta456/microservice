package com.cts.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cts.model.Purchase;
import com.cts.service.PurchaseService;

@RestController
@RequestMapping("/api")

public class PurchaseController {
	
	@Autowired
	PurchaseService purchaseService;
	
	@GetMapping(value="/PurchasePage")
	public ModelAndView show()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("PurchasePage");
		return mv;
	}
	
	@PostMapping("/savePurchaseData")
	public ModelAndView savePurchaseData(@RequestParam String purchaseItem, @RequestParam String purchasePrice)
	{
		ModelAndView mv = new ModelAndView();

		Purchase purchaseObj=new Purchase();
		purchaseObj.setPurchaseItem(purchaseItem);
		purchaseObj.setPurchasePrice(purchasePrice);
		purchaseService.save(purchaseObj);
		mv.setViewName("PurchaseSuccessPage");
		return mv;
		
	}
	
	@GetMapping("/getAllPurchaseData")
	public ModelAndView getAllData(){
		ModelAndView mv=new ModelAndView();
		List<Purchase> purchaseList=new ArrayList<>();
		purchaseList=purchaseService.getAllData();
		mv.addObject("PurchaseDetails",purchaseList);
		mv.setViewName("PurchaseDetails");
		return mv;
	}
	
	
	@GetMapping("/purchaseDelete/{id}")
	public ModelAndView purchaseDelete(@PathVariable("id") String id )
 	{
	  
	   purchaseService.purchaseDelete(Long.parseLong(id));
	   ModelAndView mv=new ModelAndView();
	   mv.setViewName("purchaseDelete");
	   return mv;
	   	   
 	}
	
	@GetMapping("/purchaseUpdate/{id}")
	
	public ModelAndView purchaseUpdate(@PathVariable("id") String id)
	
	{
		Optional<Purchase> pur=purchaseService.findById(Long.parseLong(id));
		ArrayList<Purchase> purList=new ArrayList<Purchase>();
		Purchase tempPur=new Purchase();
		if (pur.isPresent()) {
			Purchase purchase = pur.get();
			tempPur.setId(purchase.getId());
			tempPur.setPurchaseItem(purchase.getPurchaseItem());
			tempPur.setPurchasePrice(purchase.getPurchasePrice());
		}
		purList.add(tempPur);
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("purchaseUpdateData", purList);
		return new ModelAndView("PurchaseUpdate",model);
	}
	
	
	@RequestMapping(method=RequestMethod.POST ,value="/purchaseUpdate/purchaseUpdateSave")
	public ModelAndView purchaseUpdateSave(@RequestParam String id,@RequestParam String purchaseItem, @RequestParam String purchasePrice)
	{
		System.out.println("Calling purchaseUpdateSave method");
		ModelAndView mv = new ModelAndView();
		Purchase purchaseObj=new Purchase();
		purchaseObj.setId(Long.parseLong(id));
		purchaseObj.setPurchaseItem(purchaseItem);
		purchaseObj.setPurchasePrice(purchasePrice);
		purchaseService.save(purchaseObj);
		mv.setViewName("PurchaseSuccessPage");
		return mv;
		}
	
}
	

