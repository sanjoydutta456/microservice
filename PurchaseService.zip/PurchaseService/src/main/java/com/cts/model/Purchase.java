package com.cts.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Purchase {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}
private String purchaseItem;
private String purchasePrice;

public Purchase(Long id,String purchaseItem, String purchasePrice) {
	super();
	this.id=id;
	this.purchaseItem = purchaseItem;
	this.purchasePrice = purchasePrice;
}


public Purchase() {
	super();
	// TODO Auto-generated constructor stub
}


public String getPurchaseItem() {
	return purchaseItem;
}
public void setPurchaseItem(String purchaseItem) {
	this.purchaseItem = purchaseItem;
}
public String getPurchasePrice() {
	return purchasePrice;
}
public void setPurchasePrice(String purchasePrice) {
	this.purchasePrice = purchasePrice;
}



	

}
