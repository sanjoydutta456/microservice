package com.cts.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.model.LibraryBookDetails;
@Repository
public interface BookDetailsRepository extends JpaRepository <LibraryBookDetails,Long> {
	
List<LibraryBookDetails> findByBookName(String bookName);
List<LibraryBookDetails> findByBookSerialNumber(String bookSerialNumber);
List<LibraryBookDetails> findByDueDateBefore(Date dueDate);
}
