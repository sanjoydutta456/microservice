package com.cts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.model.LibraryUsers;
@Repository

public interface UserRepository extends JpaRepository <LibraryUsers,Long>{
	
	LibraryUsers findByUserNameAndPasswordAndUserType(String userName,String password, String userType);
	//JPQL
	@Query("SELECT user FROM LibraryUsers user WHERE user.userName = :userName and user.password = :password and user.userType = :userType")
	 public LibraryUsers findUser(String userName,String password, String userType);
}
