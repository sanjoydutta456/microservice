package com.cts.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class LibraryBookDetails {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public Long id;
	public String bookSerialNumber;
	public String bookName;
	public String author;
	public String status;
	public String issueDate;
	public String actualReturnDate;
	public Date dueDate;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getBookSerialNumber() {
		return bookSerialNumber;
	}
	public void setBookSerialNumber(String bookSerialNumber) {
		this.bookSerialNumber = bookSerialNumber;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}
	public String getActualReturnDate() {
		return actualReturnDate;
	}
	public void setActualReturnDate(String actualReturnDate) {
		this.actualReturnDate = actualReturnDate;
	}
	public Date getDueDate() {
		return dueDate;
	}
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}
	public LibraryBookDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LibraryBookDetails(String bookSerialNumber, String bookName, String author, String status, String issueDate,
			String actualReturnDate, Date dueDate) {
		super();
		this.bookSerialNumber = bookSerialNumber;
		this.bookName = bookName;
		this.author = author;
		this.status = status;
		this.issueDate = issueDate;
		this.actualReturnDate = actualReturnDate;
		this.dueDate = dueDate;
	}
	@Override
	public String toString() {
		return "LibraryBookDetails [bookSerialNumber=" + bookSerialNumber + ", bookName=" + bookName + ", author="
				+ author + ", status=" + status + ", issueDate=" + issueDate + ", actualReturnDate=" + actualReturnDate
				+ ", dueDate=" + dueDate + "]";
	}

	

}
