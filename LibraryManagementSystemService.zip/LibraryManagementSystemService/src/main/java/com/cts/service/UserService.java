package com.cts.service;

import java.util.List;

import com.cts.model.LibraryUsers;

public interface UserService {
	LibraryUsers saveNewUser(LibraryUsers user);
	List<LibraryUsers> findAllUserDetails();
	LibraryUsers findUserCredentialDetails(String userName, String password,String userType);
	LibraryUsers getUserCredentialDetails(String userName, String password,String userType);
	
}
