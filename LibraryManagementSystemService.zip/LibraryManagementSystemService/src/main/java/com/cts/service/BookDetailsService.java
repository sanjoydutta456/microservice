package com.cts.service;

import java.util.Date;
import java.util.List;

import com.cts.model.LibraryBookDetails;

public interface BookDetailsService  {
	
	LibraryBookDetails saveNewBookEntry(LibraryBookDetails book);
	public List<LibraryBookDetails> checkBookAvailability(String bookName);
	LibraryBookDetails bookIssue(LibraryBookDetails book);
	public List<LibraryBookDetails> checkIssuedBookDuringReturn(String bookSerialNumber);
	LibraryBookDetails bookReturn(LibraryBookDetails book);
	List<LibraryBookDetails> fineElligibility(Date dueDate)
;
}
