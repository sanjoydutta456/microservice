package com.cts.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.LibraryBookDetails;
import com.cts.repository.BookDetailsRepository;

@Service
public class BookDetailsServiceImpl implements BookDetailsService{

	@Autowired
	BookDetailsRepository bookDRepo;
	
	public LibraryBookDetails saveNewBookEntry(LibraryBookDetails book) {
	return bookDRepo.save(book);
	}
	public List<LibraryBookDetails> checkBookAvailability(String bookName) {
    return bookDRepo.findByBookName(bookName);
	}
	
	public LibraryBookDetails bookIssue(LibraryBookDetails book) {
    return bookDRepo.save(book);
	}
	
	public List<LibraryBookDetails> checkIssuedBookDuringReturn(String bookSerialNumber) {
		return bookDRepo.findByBookSerialNumber(bookSerialNumber);
	}
	
	public LibraryBookDetails bookReturn(LibraryBookDetails book) {
		return bookDRepo.save(book);
	}
	
	public List<LibraryBookDetails> fineElligibility(Date dueDate) {
		return bookDRepo.findByDueDateBefore(dueDate);
	}

}
