package com.cts.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.LibraryUsers;
import com.cts.repository.UserRepository;
@Service
public class UserServiceImpl implements UserService  {
	
	@Autowired
	UserRepository uRepo;

	public LibraryUsers saveNewUser(LibraryUsers user) {
		
		return uRepo.save(user);
	}

	
public List<LibraryUsers> findAllUserDetails() {
	
		List<LibraryUsers> userList=new ArrayList<LibraryUsers>();
		userList=uRepo.findAll();
		return userList;
	}



public LibraryUsers findUserCredentialDetails(String userName, String password,String userType) {
	//List<LibraryUsers> userList=new ArrayList<LibraryUsers>();
	LibraryUsers user=uRepo.findByUserNameAndPasswordAndUserType(userName, password, userType);
	return user;
}

public LibraryUsers getUserCredentialDetails(String userName, String password,String userType) {
	//List<LibraryUsers> userList=new ArrayList<LibraryUsers>();
	LibraryUsers user=uRepo.findUser(userName, password, userType);
	return user;
}


}
