package com.cts.controller;

import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cts.model.LibraryUsers;
import com.cts.service.UserService;
@RestController
public class UserController {

@Autowired
UserService uService;
	
	@GetMapping("/NewUserRegistration")
	public ModelAndView showreg()
	{
		ModelAndView mv= new ModelAndView();
		mv.setViewName("NewUserRegistration");
		return mv;	
	}
	
	@PostMapping("/saveNewUserDetails")
	public ModelAndView saveNewUserDetails(@RequestParam String userName, String password, String userType)
	{
		ModelAndView mv = new ModelAndView();
		LibraryUsers user= new LibraryUsers();
		user.setUserName(userName);
		user.setPassword(password);
		user.setUserType(userType);
		uService.saveNewUser(user);
		mv.setViewName("NewUserRegistrationSuccess");
		return mv;
	}
	@GetMapping("/userAdminLogin")
	public ModelAndView show()
	{
		ModelAndView mv= new ModelAndView();
		mv.setViewName("LoginPage");
		return mv;	
	}
	
	/*@PostMapping("/LogIn")
	public ModelAndView logIn(@RequestParam String userName, String password, String userType)
	{
		List<LibraryUsers> lUsers=new ArrayList<LibraryUsers>();
		ModelAndView mv = new ModelAndView();
		
		LibraryUsers user= new LibraryUsers();
		user.setUserName(userName);
		user.setPassword(password);
		user.setUserType(userType);
		lUsers.add(user);
		System.out.println("User Name:"+userName+" Password:"+password+" UserType::"+userType);
		//Iterator<LibraryUsers> itr=lUsers.iterator();
		List<LibraryUsers> dUsers=uService.findAllUserDetails();
		
		//if(lUsers.equals(dUsers))
		if(isValidUser(dUsers,user))
		{
			mv.setViewName("IndexPage");
		}
		else
		{
			mv.setViewName("WrongCredential");
		}
			return mv;		
	} */
	
	
	
	
	@PostMapping("/LogIn")
	public ModelAndView logIn(@RequestParam String userName, String password, String userType)
	{
		List<LibraryUsers> lUsers=new ArrayList<LibraryUsers>();
		ModelAndView mv = new ModelAndView();
		
		LibraryUsers user= new LibraryUsers();
		user.setUserName(userName);
		user.setPassword(password);
		user.setUserType(userType);
		lUsers.add(user);
		System.out.println("User Name:"+userName+" Password:"+password+" UserType::"+userType);
		//Iterator<LibraryUsers> itr=lUsers.iterator();
		
		//findby JPA method
		//LibraryUsers dUsers=uService.findUserCredentialDetails(userName, password, userType);
		
		//find by @query method
		LibraryUsers dUsers=uService.getUserCredentialDetails(userName, password, userType);
		System.out.println(dUsers);
		//if(lUsers.equals(dUsers))
		if(dUsers !=null)
		{
			mv.setViewName("IndexPage");
		}
		else
		{
			mv.setViewName("WrongCredential");
		}
			return mv;		
	} 
	
	
	public boolean isValidUser(List<LibraryUsers> dUsers,LibraryUsers user)
	{
		boolean isValid=false;
		for(LibraryUsers luser:dUsers)
		{
			System.out.println(luser);
			if(luser.getUserName().equals(user.getUserName()) 
					&& luser.getPassword().equals(user.getPassword())
					&& luser.getUserType().equals(user.getUserType()))
			{
				isValid=true;
				break;
			}
		}
		
		return isValid;
	}
}
