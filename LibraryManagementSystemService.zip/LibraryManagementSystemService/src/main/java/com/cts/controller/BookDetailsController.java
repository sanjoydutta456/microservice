package com.cts.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cts.model.LibraryBookDetails;
import com.cts.service.BookDetailsService;

@RestController
public class BookDetailsController {
	
	@Autowired
	BookDetailsService bookDService;
	
	@GetMapping("/NewBookEntery")
	public ModelAndView show()
	{
		ModelAndView mv= new ModelAndView();
		mv.setViewName("BookEntry");
		return mv;	
	}
	
	@PostMapping("/saveNewBookEntry")
	public ModelAndView saveNewBookEntry(@RequestParam String bookSerialNumber, String bookName, String author, String status)
	{
		ModelAndView mv = new ModelAndView();
		LibraryBookDetails lbd= new LibraryBookDetails();
		lbd.setBookSerialNumber(bookSerialNumber);
		lbd.setBookName(bookName);
        lbd.setAuthor(author);
		lbd.setStatus(status);
		bookDService.saveNewBookEntry(lbd);
		mv.setViewName("BookEntrySuccess");
		return mv;
	}
	
	@GetMapping("/searchOperationAndBookIssue")
	public ModelAndView search()
	{
		ModelAndView mv= new ModelAndView();
		mv.setViewName("SearchBook");
		return mv;	
	}
	
	@GetMapping("/checkBookAvailability")
	public ModelAndView checkBookAvailability(@RequestParam String bookName)
	{
		List<LibraryBookDetails> lbd=new ArrayList<LibraryBookDetails>();		
		lbd=bookDService.checkBookAvailability(bookName);
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("bookDetailsByNamne", lbd);
		return new ModelAndView("CheckBookAvailability",model);	
	}
	
	@RequestMapping(method=RequestMethod.POST ,value="/bookIssue")
	public ModelAndView bookIssue(@RequestParam String id,@RequestParam String bookSerialNumber,
			@RequestParam String bookName,@RequestParam String author, 
			@RequestParam String status,@RequestParam String issueDate, @RequestParam Date dueDate)
	
	{
		ModelAndView mv = new ModelAndView();
		LibraryBookDetails lbd=new LibraryBookDetails();
		lbd.setId(Long.parseLong(id));
		lbd.setBookSerialNumber(bookSerialNumber);
		lbd.setBookName(bookName);
		lbd.setAuthor(author);
		lbd.setStatus(status);
		lbd.setIssueDate(issueDate);
		lbd.setDueDate(dueDate);
		bookDService.bookIssue(lbd);
		mv.setViewName("BookIssueSuccess");
		return mv;
	}
	
	
	@GetMapping("/returnOperation")
	public ModelAndView returnOperation()
	{
		ModelAndView mv= new ModelAndView();
		mv.setViewName("ReturnOperation");
		return mv;	
	}
	
	@GetMapping("/checkIssuedBookDuringReturn")
	public ModelAndView checkIssuedBookDuringReturn(@RequestParam String bookSerialNumber)
	{
		List<LibraryBookDetails> lbd=new ArrayList<LibraryBookDetails>();		
		lbd=bookDService.checkIssuedBookDuringReturn(bookSerialNumber);
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("bookDetailsBySerialNumber", lbd);
		return new ModelAndView("CheckIssuedBookDuringReturn",model);	
	}
	
	@RequestMapping(method=RequestMethod.POST ,value="/bookReturn")
	public ModelAndView bookReturn(@RequestParam String id,@RequestParam String bookSerialNumber,
			@RequestParam String bookName,@RequestParam String author, 
			@RequestParam String status,@RequestParam String issueDate, @RequestParam String actualReturnDate,@RequestParam String dueDate) throws ParseException
	
	{
		Date d2=null;
		if(!StringUtils.isEmpty(dueDate))
		{
		SimpleDateFormat d1=new SimpleDateFormat("dd-mm-YYYY");
		 d2=d1.parse(dueDate);
		}
		ModelAndView mv = new ModelAndView();
		LibraryBookDetails lbd=new LibraryBookDetails();
		lbd.setId(Long.parseLong(id));
		lbd.setBookSerialNumber(bookSerialNumber);
		lbd.setBookName(bookName);
		lbd.setAuthor(author);
		lbd.setStatus(status);
		lbd.setIssueDate(issueDate);
		lbd.setActualReturnDate(actualReturnDate);
		lbd.setDueDate(d2);
		bookDService.bookReturn(lbd);
		mv.setViewName("BookReturnSuccess");
		return mv;
	}
	
	@GetMapping("/checkFineForBook")
	public ModelAndView fineOperation()
	{
		ModelAndView mv= new ModelAndView();
		mv.setViewName("FineForBook");
		return mv;	
	}
	
@GetMapping("/fineElligibility")
public ModelAndView fineElligibility(@RequestParam Date dueDate)
{
	 List<LibraryBookDetails> lbd=new ArrayList<LibraryBookDetails>();
	 lbd=bookDService.fineElligibility(dueDate);
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("fineElligibleBooks", lbd);
		return new ModelAndView("FineElligibleBooks",model);
	 
}

	
}
