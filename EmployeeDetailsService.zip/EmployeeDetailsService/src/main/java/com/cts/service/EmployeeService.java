package com.cts.service;

import java.util.List;

import com.cts.model.Employees;

public interface EmployeeService {

	Employees createEmployeeDetails(Employees emp);
	List<Employees> getAllEmployeeDetails();
}
