package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Employees;
import com.cts.repository.EmployeesRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired 
	EmployeesRepository empRepo;
	
	public Employees createEmployeeDetails(Employees emp) {
		
		return empRepo.save(emp);
	}

	
	public List<Employees> getAllEmployeeDetails() {
		
		return empRepo.findAll();
	}

	
}
