package com.cts.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.cts.model.Employees;


@FeignClient(name="employees-service")
public interface EmployeeDashboardService {

	@GetMapping(value="/api/getAllEmployeeDetails")
	public List<Employees> getEmployeeDetails();
	
	
}
