package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.Employees;
import com.cts.service.EmployeeDashboardService;

@RestController
@RequestMapping(value="/employeeDashboard")

public class EmployeeDasboardController {

	@Autowired
	EmployeeDashboardService empDashboardService;
	
	@GetMapping("/getAllEmployeeDetails")
	public List<Employees> getAllEmployeeDetails()
	{
		return empDashboardService.getEmployeeDetails();
	}
	
}
