package com.cts.repository;

public class EmployeesDashboardRepository {

}
